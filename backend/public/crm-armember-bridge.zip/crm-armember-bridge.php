<?php
/*
Plugin Name: CRM Club VIP Bridge
Description: Puente de conexión seguro entre el CRM y WordPress. Sincroniza visualmente el estado con ARMember y bloquea accesos.
Version: 1.2
Author: CRM System
*/

if (!defined('ABSPATH')) {
    exit;
}

// 1. Bloquear login (Nuestro candado universal de seguridad)
add_filter('authenticate', 'crm_bridge_check_suspended_user', 100, 3);
function crm_bridge_check_suspended_user($user, $username, $password) {
    if ($user instanceof WP_User) {
        $status = get_user_meta($user->ID, 'crm_status', true);
        if ($status === 'suspended') {
            return new WP_Error('suspended_account', '<strong>Acceso Denegado:</strong> Tu membresía se encuentra inactiva. Por favor, regulariza tu pago para recuperar el acceso al Club VIP.');
        }
    }
    return $user;
}

// 2. Endpoint REST para el CRM
add_action('rest_api_init', function () {
    register_rest_route('crm/v1', '/status/(?P<id>\d+)', array(
        'methods' => 'POST',
        'callback' => 'crm_bridge_update_status',
        'permission_callback' => function () {
            return current_user_can('edit_users');
        }
    ));
});

function crm_bridge_update_status($request) {
    global $wpdb;
    $user_id = $request['id'];
    $status = $request->get_param('status'); // 'active' o 'suspended'

    if (!get_userdata($user_id)) {
        return new WP_Error('no_user', 'Usuario no encontrado', array('status' => 404));
    }

    // A. Actualizar nuestra meta universal
    update_user_meta($user_id, 'crm_status', $status);
    
    // Fallbacks comunes de ARMember en User Meta (algunos themes/versiones leen de aquí)
    $status_code = ($status === 'suspended') ? 2 : 1;
    update_user_meta($user_id, 'arm_user_status', $status_code);
    update_user_meta($user_id, 'arm_user_plan_status', $status_code);

    // B. Sincronizar visualmente con la tabla interna de ARMember
    $table_name = $wpdb->prefix . 'arm_members';
    $db_updated = false;
    
    // Ignoramos errores si la tabla no existe en alguna version Lite
    $wpdb->suppress_errors = true;
    
    $result = $wpdb->update(
        $table_name,
        array('arm_user_status' => $status_code),
        array('arm_user_id' => $user_id),
        array('%d'),
        array('%d')
    );
    
    if ($result !== false) {
        $db_updated = true;
    }

    return rest_ensure_response(array(
        'success' => true, 
        'status' => $status, 
        'synced_armember_db' => $db_updated,
        'user_id' => $user_id
    ));
}
